Fonctionnement du script inspiré des boids

Si j'appuie sur E et qu'un poussin est sur mon RayCast il me suis.
Lorsque le poussin est trop loin, il accelere.
Si je m'eloigne encore plus le poussin arrete de me suivre, vitesse a 0.
Le poussin se tourne toujours dans la direction de son deplacement.


ASSETS UNITY UTILISE:

- Free Island Collection
- Island
- MegaPack1Lite
- Meshtint Free Chick Mega Toon Series
- ModularFirstPersonController
- NatureStarterKit
